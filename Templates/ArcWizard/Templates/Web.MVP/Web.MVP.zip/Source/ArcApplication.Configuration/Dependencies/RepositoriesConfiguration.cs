using Ninject.Core;

namespace $safeprojectname$.Dependencies
{
    public class RepositoriesConfiguration : StandardModule
    {
        public override void Load()
        {
     
        }
    }
}