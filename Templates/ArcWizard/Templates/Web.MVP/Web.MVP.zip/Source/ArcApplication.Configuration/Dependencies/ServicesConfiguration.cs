using Ninject.Core;

namespace $safeprojectname$.Dependencies
{
    public class ServicesConfiguration : StandardModule
    {
        public override void Load()
        {
        }
    }
}