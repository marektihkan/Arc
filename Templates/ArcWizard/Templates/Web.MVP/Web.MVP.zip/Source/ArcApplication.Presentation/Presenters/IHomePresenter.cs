namespace $safeprojectname$.Presenters
{
    public interface IHomePresenter
    {
    }
}