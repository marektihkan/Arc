namespace $safeprojectname$.Presenters.Templates
{
    public interface ISiteTemplatePresenter
    {
    }
}