namespace $safeprojectname$.Views
{
    public interface IHomeView
    {
        
    }
}