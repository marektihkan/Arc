namespace $safeprojectname$.Views.Templates
{
    public interface ITemplateView
    {
        
    }
}